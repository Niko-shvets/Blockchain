// Copyright 2018 The Exonum Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


//!
//! **Note.** The service in this crate is intended for demo purposes only. It is not intended
//! for use in production.
//!
//! [exonum]: https://github.com/exonum/exonum
//! [docs]: https://exonum.com/doc/get-started/create-service
//! [readme]: https://github.com/exonum/cryptocurrency#readme

#![deny(
    missing_debug_implementations,
    missing_docs,
    unsafe_code,
    bare_trait_objects
)]

extern crate exonum;
#[macro_use]
extern crate exonum_derive;
#[macro_use]
extern crate failure;
extern crate serde;
#[macro_use]
extern crate serde_derive;
extern crate protobuf;
extern crate serde_json;

extern crate shamir;
extern crate threshold_secret_sharing as tss;

pub mod proto;

/// Persistent data.
pub mod schema {
    use exonum::{
        crypto::PublicKey,
        storage::{Fork, MapIndex, Snapshot},
    };

    use super::proto;

    // Declare the data to be stored in the blockchain, namely Users with key_shards.
    // See [serialization docs][1] for details.
    //
    // [1]: https://exonum.com/doc/architecture/serialization
    /// User struct used to persist data within the service.
    #[derive(Serialize, Deserialize, Clone, Debug, ProtobufConvert)]
    #[exonum(pb = "proto::User")]
    pub struct User {
        /// Public key of the user owner.
        pub pub_key: PublicKey,
        /// Name of the user owner.
        pub name: String,
        /// Current key_shard.
        pub key_shard: u64,
    }

    /// Additional methods for managing key_shard of the user in an immutable fashion.
    impl User {
        /// Create new User.
        pub fn new(&pub_key: &PublicKey, name: &str, key_shard: &u64) -> Self {
            Self {
                pub_key,
                name: name.to_owned(),
                key_shard: key_shard.to_owned(),
            }
        }

    }

    /// Schema of the key-value storage used by the demo cryptocurrency service.
    #[derive(Debug)]
    pub struct CurrencySchema<T> {
        view: T,
    }

    /// Declare the layout of data managed by the service. An instance of [`MapIndex`] is used
    /// to keep users in the storage. Index values are serialized [`User`] structs.
    ///
    /// [`MapIndex`]: https://exonum.com/doc/architecture/storage#mapindex
    /// [`User`]: struct.User.html
    impl<T: AsRef<dyn Snapshot>> CurrencySchema<T> {
        /// Creates a new schema instance.
        pub fn new(view: T) -> Self {
            CurrencySchema { view }
        }

        /// Returns an immutable version of the users table.
        pub fn users(&self) -> MapIndex<&dyn Snapshot, PublicKey, User> {
            MapIndex::new("cryptocurrency.users", self.view.as_ref())
        }

        /// Gets a specific user from the storage.
        pub fn user(&self, pub_key: &PublicKey) -> Option<User> {
            self.users().get(pub_key)
        }
    }

    /// A mutable version of the schema with an additional method to persist users
    /// to the storage.
    impl<'a> CurrencySchema<&'a mut Fork> {
        /// Returns a mutable version of the users table.
        pub fn users_mut(&mut self) -> MapIndex<&mut Fork, PublicKey, User> {
            MapIndex::new("cryptocurrency.users", &mut self.view)
        }
    }
}

/// Transactions.
pub mod transactions {
    use super::proto;
    use super::service::SERVICE_ID;
    use exonum::{
        crypto::{PublicKey, SecretKey},
        messages::{Message, RawTransaction, Signed},
    };
    /// Transaction type for creating a new user.
    ///
    /// See [the `Transaction` trait implementation](#impl-Transaction) for details how
    /// `TxCreateUser` transactions are processed.
    #[derive(Serialize, Deserialize, Clone, Debug, ProtobufConvert)]
    #[exonum(pb = "proto::TxCreateUser")]
    pub struct TxCreateUser {
        /// UTF-8 string with the owner's name.
        pub name: String,
        /// key which we shard
        pub key_shard: u64,
    }

    /// Transaction type for change document.
    ///
    /// See [the `Transaction` trait implementation](#impl-Transaction) for details how
    /// `TxChangeDoc` transactions are processed.
    #[derive(Serialize, Deserialize, Clone, Debug, ProtobufConvert)]
    #[exonum(pb = "proto::TxChangeDoc")]
    pub struct TxChangeDoc {
        /// vector array of keys
        pub list_keys: Vec<Vec<u8>>, // array u64
        /// string with lines_number
        pub lines_number: String, //String
        /// string new_value
        pub new_value: String,
    }

    /// Transaction type for validate changing document.
    ///
    /// See [the `Transaction` trait implementation](#impl-Transaction) for details how
    /// `TxValidChange` transactions are processed.
    #[derive(Serialize, Deserialize, Clone, Debug, ProtobufConvert)]
    #[exonum(pb = "proto::TxValidChange")]
    pub struct TxValidChange{
        /// hash of changing tx
        pub hash_tx_change: u64,
        /// string with lines_number
        pub lines_number: String,
        /// old hash of tx
        pub old_hash: u64,
        /// new hash of tx
        pub new_hash: u64,

    }

    /// Transaction group.
    #[derive(Serialize, Deserialize, Clone, Debug, TransactionSet)]
    pub enum CurrencyTransactions {
        /// Create user transaction.
        CreateUser(TxCreateUser),
        /// Request of Document change tx
        ChangeDoc(TxChangeDoc),
        /// Validate Changes tx
        ValidChange(TxValidChange),
    }

    impl TxCreateUser {
        #[doc(hidden)]
        pub fn sign(name: &str,key_shard: &u64, pk: &PublicKey, sk: &SecretKey) -> Signed<RawTransaction> {
            Message::sign_transaction(
                Self {
                    name: name.to_owned(),
                    key_shard: key_shard.to_owned(),
                },
                SERVICE_ID,
                *pk,
                sk,
            )
        }
    }

    impl  TxChangeDoc{
        #[doc(hidden)]
        pub fn sign(list_keys : Vec<Vec<u8>>,lines_number: &str,new_value: &str, pk: &PublicKey,sk: &SecretKey,) -> Signed<RawTransaction> 
        {
            Message::sign_transaction(
                Self {
                    list_keys,
                    lines_number: lines_number.to_owned(),
                    new_value: new_value.to_owned(),},
                SERVICE_ID,
                *pk,
                sk,
            )
        }
    }

    impl TxValidChange {
        #[doc(hidden)]
        pub fn sign(hash_tx_change: u64, lines_number: &str, old_hash: u64, new_hash: u64,pk: &PublicKey, sk: &SecretKey,) -> Signed<RawTransaction> {
            Message::sign_transaction(
                Self {hash_tx_change,
                lines_number: lines_number.to_owned(),
                old_hash,new_hash,},
                SERVICE_ID,
                *pk,
                sk,
            )
        }
    }

}

/// Contract errors.
pub mod errors {
    // Workaround for `failure` see https://github.com/rust-lang-nursery/failure/issues/223 and
    // ECR-1771 for the details.
    #![allow(bare_trait_objects)]

    use exonum::blockchain::ExecutionError;

    /// Error codes emitted by `TxCreateUser` and/or  transactions during execution.
    #[derive(Debug, Fail)]
    #[repr(u8)]
    pub enum Error {
        /// User already exists.
        ///
        /// Can be emitted by `TxCreateUser`.
        #[fail(display = "User already exists")]
        UserAlreadyExists = 0,
        /// old_hash is not equal to new_hash.
        ///
        /// Can be emitted by `TxCreateUser`.
         #[fail(display = "Old hash is not equal to new_hash")]
        OldHashNEqNew = 1,
    }

    impl From<Error> for ExecutionError {
        fn from(value: Error) -> ExecutionError {
            let description = format!("{}", value);
            ExecutionError::with_description(value as u8, description)
        }
    }
}

/// Contracts.
pub mod contracts {
    use exonum::blockchain::{ExecutionResult, Transaction, TransactionContext};

    use errors::Error;
    use schema::{CurrencySchema, User};
    use transactions::{TxCreateUser,TxChangeDoc,TxValidChange};


    impl Transaction for TxCreateUser {
        /// If a User with the specified public key is not registered, then creates a new User
        /// with the specified public key and name, and an initial key_shard of 100.
        /// Otherwise, performs no op.
        fn execute(&self, mut context: TransactionContext) -> ExecutionResult {
            let author = context.author();
            let view = context.fork();
            let mut schema = CurrencySchema::new(view);
            if schema.user(&author).is_none() {
                let user = User::new(&author, &self.name, &self.key_shard);
                println!("Create the user: {:?}", user);
                schema.users_mut().put(&author, user);
                Ok(())
            } else {
                Err(Error::UserAlreadyExists)?
            }
        }
    }

    impl Transaction for TxChangeDoc{
        /// Retrieves document lines and line numbers to change; Afer that we apply
        /// Shamir method(function) to calculate the common secret key,that TxChangeDoc 
        /// should return
         fn execute(&self, mut context: TransactionContext) -> ExecutionResult {

            use shamir::SecretData;
            let ref v = &self.list_keys;
            let mut x = 0;
            for i in v.to_vec() {
                x+=1;
            }
            let recovered = SecretData::recover_secret(x, v.to_vec()).unwrap();
            Ok(())
         }
    }

    impl Transaction for TxValidChange{ 
        /// There we validate our txs because there hashes should be equal
         fn execute(&self, mut context: TransactionContext) -> ExecutionResult {
            if &self.old_hash == &self.new_hash{
                        Ok(())
            }
            else{
                Err(Error::OldHashNEqNew)?
            }

         }
    }
}

/// REST API.
pub mod api {
    use exonum::{
        api::{self, ServiceApiBuilder, ServiceApiState},
        crypto::PublicKey,
    };

    use schema::{CurrencySchema, User};

    /// Public service API description.
    #[derive(Debug, Clone)]
    pub struct CryptocurrencyApi;

    /// The structure describes the query parameters for the `get_user` endpoint.
    #[derive(Debug, Serialize, Deserialize, Clone, Copy)]
    pub struct UserQuery {
        /// Public key of the queried user.
        pub pub_key: PublicKey,
    }

    impl CryptocurrencyApi {
        /// Endpoint for getting a single user.
        pub fn get_user(state: &ServiceApiState, query: UserQuery) -> api::Result<User> {
            let snapshot = state.snapshot();
            let schema = CurrencySchema::new(snapshot);
            schema
                .user(&query.pub_key)
                .ok_or_else(|| api::Error::NotFound("\"User not found\"".to_owned()))
        }

        /// Endpoint for dumping all users from the storage.
        pub fn get_users(state: &ServiceApiState, _query: ()) -> api::Result<Vec<User>> {
            let snapshot = state.snapshot();
            let schema = CurrencySchema::new(snapshot);
            let idx = schema.users();
            let users = idx.values().collect();
            Ok(users)
        }

        /// 'ServiceApiBuilder' facilitates conversion between read requests and REST
        /// endpoints.
        pub fn wire(builder: &mut ServiceApiBuilder) {
            // Binds handlers to specific routes.
            builder
                .public_scope()
                .endpoint("v1/user", Self::get_user)
                .endpoint("v1/users", Self::get_users);
        }
    }
}

/// Service declaration.
pub mod service {
    use exonum::{
        api::ServiceApiBuilder,
        blockchain::{Service, Transaction, TransactionSet},
        crypto::Hash,
        messages::RawTransaction,
        storage::Snapshot,
    };

    use api::CryptocurrencyApi;
    use transactions::CurrencyTransactions;

    /// Service ID for the `Service` trait.
    pub const SERVICE_ID: u16 = 1;

    /// Demo cryptocurrency service.
    ///
    /// See [the crate documentation](index.html) for context.
    ///
    /// # Public REST API
    ///
    /// In all APIs, the request body (if applicable) and response are JSON-encoded.
    ///
    /// ## Retrieve single user
    ///
    /// GET `api/services/cryptocurrency/v1/user/?pub_key={hash}`
    ///
    /// Returns information about a user with the specified public key (hex-encoded).
    /// If a user with the specified pubkey is not in the storage, returns a string
    /// `"User not found"` with the HTTP 404 status.
    ///
    /// ## Dump users
    ///
    /// GET `api/services/cryptocurrency/v1/users`
    ///
    /// Returns an array of all users in the storage.
    ///
    /// ## Transactions endpoint
    ///
    /// POST `api/explorer/v1/transactions`
    ///
    /// Accepts a [`TxTransfer`] and [`TxCreateUser`] transaction from an external client.
    /// Transaction should be serialized into protobuf binary form and placed into signed
    /// transaction message according to specification, endpoint accepts hex of this signed
    /// transaction message as an object: `{ "tx_body": <hex> }`.
    ///
    /// Returns the hex-encoded hash of the transaction
    /// encumbered in an object: `{ "tx_hash": <hash> }`.
    ///
    /// [`TxCreateUser`]: ../transactions/struct.TxCreateUser.html
    /// [`TxTransfer`]: ../transactions/struct.TxTransfer.html
    #[derive(Debug)]
    pub struct CurrencyService;

    impl Service for CurrencyService {
        fn service_name(&self) -> &'static str {
            "cryptocurrency"
        }

        fn service_id(&self) -> u16 {
            SERVICE_ID
        }

        // Implement a method to deserialize transactions coming to the node.
        fn tx_from_raw(&self, raw: RawTransaction) -> Result<Box<dyn Transaction>, failure::Error> {
            let tx = CurrencyTransactions::tx_from_raw(raw)?;
            Ok(tx.into())
        }

        // Hashes for the service tables that will be included into the state hash.
        // To simplify things, we don't have [Merkelized tables][merkle] in the service storage
        // for now, so we return an empty vector.
        //
        // [merkle]: https://exonum.com/doc/architecture/storage/#merklized-indices
        fn state_hash(&self, _: &dyn Snapshot) -> Vec<Hash> {
            vec![]
        }

        // Links the service api implementation to the Exonum.
        fn wire_api(&self, builder: &mut ServiceApiBuilder) {
            CryptocurrencyApi::wire(builder);
        }
    }
}
